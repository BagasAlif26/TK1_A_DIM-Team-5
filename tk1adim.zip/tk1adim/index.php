<?php
class KoneksiDatabase {
    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $db = "portalberita";
    protected $koneksi;

    public function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->user, $this->pass, $this->db);
        if (!$this->koneksi) {
            die("Tidak bisa terkoneksi ke database");
        }
    }

    public function getKoneksi() {
        return $this->koneksi;
    }
}

class Artikel extends KoneksiDatabase {
    public function __construct() {
        parent::__construct();
    }

    public function cariArtikel($search_keyword) {
        $search_keyword = mysqli_real_escape_string($this->getKoneksi(), $search_keyword);
        $sql_artikel = "SELECT * FROM `artikel` 
                        WHERE judul LIKE '%$search_keyword%' 
                        OR konten LIKE '%$search_keyword%' 
                        OR penulis LIKE '%$search_keyword%' 
                        ORDER BY tanggal_update DESC";
        return mysqli_query($this->getKoneksi(), $sql_artikel);
    }
}

class ProfilPerusahaan extends KoneksiDatabase {
    public function __construct() {
        parent::__construct();
    }

    public function ambilProfil() {
        $sql_profil = "SELECT * FROM `profil_perusahaan` LIMIT 1";
        return mysqli_query($this->getKoneksi(), $sql_profil);
    }
}

$artikelObj = new Artikel();
$profilObj = new ProfilPerusahaan();

$profilQuery = $profilObj->ambilProfil();
$profil = mysqli_fetch_assoc($profilQuery);

$search_keyword = isset($_GET['search']) ? $_GET['search'] : '';
$artikelQuery = $artikelObj->cariArtikel($search_keyword);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Berita Pemerintah A</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .mx-auto {
            width: 1200px;
        }
        .card {
            margin-top: 20px;
        }
        .title-wrapper {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-bottom: 20px;
            font-size: 2em;
            font-weight: bold;
        }
        .profil-wrapper {
            font-size: 1em;
        }
        .profil-wrapper h3 {
            font-size: 1.5em;
        }
        .profil-wrapper p {
            font-size: 0.9em;
            line-height: 1.5em;
        }
        .search-wrapper {
            margin-bottom: 20px;
        }
        .search-wrapper input {
            width: calc(100% - 120px);
        }
        .search-wrapper button {
            width: 100px;
        }
    </style>
</head>
<body>

<div class="mx-auto">
    <!-- Judul Besar -->
    <div class="title-wrapper">
        Selamat Datang di Portal Berita Pemerintah A
    </div>

    <!-- Profil Perusahaan -->
    <div class="card">
        <div class="card-body profil-wrapper">
            <h3><?php echo htmlspecialchars($profil['nama_perusahaan']); ?></h3>
            <p><?php echo htmlspecialchars($profil['deskripsi']); ?></p>
            <p><strong>Alamat:</strong> <?php echo htmlspecialchars($profil['alamat']); ?></p>
            <p><strong>Telepon:</strong> <?php echo htmlspecialchars($profil['telepon']); ?></p>
        </div>
    </div>

    <!-- Pencarian Artikel -->
    <div class="card">
        <div class="card-header text-white bg-secondary">
            Pencarian Artikel
        </div>
        <div class="card-body">
            <div class="search-wrapper">
                <form method="GET" action="">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Cari artikel..." value="<?php echo htmlspecialchars($search_keyword); ?>">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </form>
            </div>

            <!-- Daftar Artikel -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Judul</th>
                        <th scope="col">Konten</th>
                        <th scope="col">Penulis</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Tanggal Update</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Periksa jika query berhasil
                    if ($artikelQuery) {
                        $no = 1;
                        while ($row_artikel = mysqli_fetch_assoc($artikelQuery)) {
                            // Menggunakan htmlspecialchars untuk mencegah karakter khusus yang merusak HTML
                            $judul = htmlspecialchars($row_artikel['judul']);
                            $konten = htmlspecialchars($row_artikel['konten']);
                            $penulis = htmlspecialchars($row_artikel['penulis']);
                            $kategori = htmlspecialchars($row_artikel['kategori']);
                            $tanggal_update = htmlspecialchars($row_artikel['tanggal_update']);
                    ?>
                        <tr>
                            <th scope="row"><?php echo $no++; ?></th>
                            <td><?php echo $judul; ?></td>
                            <td><?php echo $konten; ?></td>
                            <td><?php echo $penulis; ?></td>
                            <td><?php echo $kategori; ?></td>
                            <td><?php echo $tanggal_update; ?></td>
                        </tr>
                    <?php
                        }
                    } else {
                        echo "<tr><td colspan='6'>Tidak ada data artikel</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
